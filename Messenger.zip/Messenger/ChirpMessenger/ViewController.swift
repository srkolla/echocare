/*------------------------------------------------------------------------------
 *
 *  ViewController.swift
 *
 *  For full information on usage and licensing, see https://chirp.io/
 *
 *  Copyright © 2011-2019, Asio Ltd.
 *  All rights reserved.
 *
 *----------------------------------------------------------------------------*/

import UIKit
import AVFoundation

var uuid: String?
var checkinFlag: Bool?
var recUUID: String?

extension String {
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }

    func substring(from: Int) -> String {
        let fromIndex = index(from: from)
        return String(self[fromIndex...])
    }

    func substring(to: Int) -> String {
        let toIndex = index(from: to)
        return String(self[..<toIndex])
    }

    func substring(with r: Range<Int>) -> String {
        let startIndex = index(from: r.lowerBound)
        let endIndex = index(from: r.upperBound)
        return String(self[startIndex..<endIndex])
    }
}

class ViewController: UIViewController, UITextViewDelegate {

    let chirpGrey: UIColor = UIColor(red: 84.0 / 255.0, green: 84.0 / 255.0, blue: 84.0 / 255.0, alpha: 1.0)
    let chirpBlue: UIColor = UIColor(red: 43.0 / 255.0, green: 74.0 / 255.0, blue: 201.0 / 255.0, alpha: 1.0)

    override func viewDidLoad() {
        super.viewDidLoad()
        checkinFlag = false
        recUUID = ""
//        self.sendInput1() //uuid
        
 //       let timer = Timer.scheduledTimer(timeInterval: 30.0, target: self, selector: #selector(fire), userInfo: nil, repeats: true)


        // Listen for app going to the background
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(appMovedToBackground),
            name: UIApplication.willResignActiveNotification,
            object: nil
        )
        
        // Minimise keyboard when touching outside
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard (_:)))
        self.view.addGestureRecognizer(tapGesture)

        // Add padding to textViews
        self.inputText.textContainerInset = UIEdgeInsets(top: 15, left: 10, bottom: 15, right: 10)
        self.receivedText.textContainerInset = UIEdgeInsets(top: 15, left: 10, bottom: 15, right: 10)

        // Set up some colours for buttons
        self.sendButton.setTitleColor(UIColor.white, for: .disabled)
        self.clearButton.setTitleColor(UIColor.white, for: .disabled)
        
        self.pingUUIDButton.setTitleColor(UIColor.white, for: .disabled)
        self.configureClearButton(enabled: false, title: "CLEAR", colour: self.chirpBlue)
        self.configurePingUUIDButton(enabled: true, title: "CHECK-IN", colour: self.chirpBlue)

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        if let sdk = appDelegate.sdk {

            print(sdk.version);

            sdk.sendingBlock = {
                (data : Data?, channel: UInt?) -> () in
                self.configureSendButton(enabled: false, title: "SENDING", colour: self.chirpGrey)
                return;
            }
            
            sdk.sentBlock = {
                (data : Data?, channel: UInt?) -> () in
                self.configureSendButton(enabled: true, title: "SEND", colour: self.chirpBlue)
                return;
            }

            sdk.receivingBlock = {
                (channel: UInt?) -> () in
                self.configureSendButton(enabled: false, title: "RECEIVING", colour: self.chirpGrey)
                 // self.receivedText.text = "...."
                  self.receivedText.text =  self.receivedText.text + ""
                    return;
            }

            sdk.receivedBlock = {
                (data : Data?, channel: UInt?) -> () in
                self.configureSendButton(enabled: true, title: "SEND", colour: self.chirpBlue)
               // if self.inputText.text == "...." {
                //    self.inputText.text = ""
               // }
                
               // var payloadString = String("")
               // if let data = data {
                //    if let payload = String(data: data, encoding: .utf8) {
                var roomString = String("")
                 roomString = "loc220" //Default room
                var payloadString = String("")
                var payloadTmp = String("")
                
                 if let data = data {
                     if let payload = String(data: data, encoding: .utf8) {
                         if (payload.count == 7)
                         {
                            payloadTmp = payload
                             roomString = "loc"+payloadTmp.substring(from:4)
                             payloadTmp = payloadTmp.substring(to:4)
                         }
                        else
                         {
                            payloadTmp = payload
                         }
                        if payloadTmp == "1111"
                        {
                                                   payloadString = "EchoCare team welcomes you to Hackathon 2020 GBT Techonology Event! \n "
                                               }
                                               else if payloadTmp == "2222"{
                                                   payloadString = "Thanks for event check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                               }
                                                else if payloadTmp == "3333"{
                                                    payloadString = "GBT Hackathon 2020 winners announcement to be held tomorrow at 4:00 PM MST in cafeteria. \n "
                                                }
                                                else if payloadTmp == "4444"{
                                                    payloadString = "EMERGENCY EVACUATION ALERT: Please follow EXIT sign to reach nearest exit. \n "
                                                }
                                                else if payloadTmp == "5555"{
                                                    payloadString = "For your information - Dell Boomi event booth location has been changed from 238 to 202 i.e. SW corner of the venue. \n "
                                                }
                                                else if payloadTmp == "6666"{
                                                    payloadString = "For your information - NetSuite technology demo is going to start in next 10 minutes at booth 220 i.e. SE corner of the venue. \n"
                                                }
                                                else if payloadTmp == "7777"{
                                                    payloadString = "Thank you for joining the GBT Hackathon 2020 event & hope you had great experience! \n"
                                                }
                                                else if payloadTmp == "8888"{
                                                    payloadString = "Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                }
                                                else if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                {
                                                    payloadString = "" //Channel 1 for only actual messages (not for UUID or Welcome msg) //UIDevice.current.identifierForVendor!.uuidString.substring(from:31)+":"+"Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                }
                                                else if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                {
                                                    payloadString = ""//Do nothing from same device
                                                }
                        else
                        {
                            
                            if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                            {
                                payloadString = "" //Do nothing from same device
                            }
                            else if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                            {
                                payloadString = ""
                            }
                            else
                            {
                                if (payloadTmp.count == 4 || payloadTmp.substring(to:1) == "$")
                                {
                                    payloadString = ""
                                }
                                else
                                {
                                    payloadString = payloadTmp
                                }
                               // payloadString = "UDID: " + payload
                            }
                            
                            //Channel 1 for only actual messages (not for UUID or Welcome msg)
                            /*
                            print(String(format: "UDID Received: %@", payload))
                                                   
                                                   print(String(format: "Calling WebService.....Start \n"))
                                                  
                                                    let urlString = "http://localhost:8080/updateUserLocation?userid=100&locationid=loc206"
                                         //
                                                   print(String(format: "WebService call completed.....End \n"))
                            */
                        }
                        if (payloadString != "")
                        {
                            self.receivedText.text = payloadString + "\n" + self.receivedText.text
                            print(String(format: "Received: %@", payloadString))
                        }
                                               /*
                                               if(checkinFlag == true)
                                               {
                                                   print("checkinFlag is true")
                                                   checkinFlag = false
                                                   print("checkinFlag set to false")
                                                   recUUID = "$"+payload
                                                   print(String(format: "recUUID set to: %@", recUUID ?? ""))
                                                   print("Calling sendWelcomeMsg")
                                                   self.sendWelcomeMsg()
                                                   //self.sendThankYouMsg()
                                               }
                                            */
                    } else {
                        print("Failed to decode payload!")
                    }
                } else {
                    print("Decode failed!")
                }
                return;
            }
        }
        if let sdk1 = appDelegate.sdk1 {

            print(sdk1.version);

            sdk1.sendingBlock = {
                (data : Data?, channel: UInt?) -> () in
                print("SENDING UUID \n")
                return;
            }
            
            sdk1.sentBlock = {
                (data : Data?, channel: UInt?) -> () in
                print("SENT UUID \n")
                return;
            }

            sdk1.receivingBlock = {
                (channel: UInt?) -> () in
                self.configureSendButton(enabled: false, title: "RECEIVING UDID", colour: self.chirpGrey)
                 // self.receivedText.text = "...."
                  self.receivedText.text =  self.receivedText.text + ""
                    return;
            }

            sdk1.receivedBlock = {
                (data : Data?, channel: UInt?) -> () in
                 self.configureSendButton(enabled: true, title: "SEND", colour: self.chirpBlue)
               // if self.inputText.text == "...." {
                //    self.inputText.text = ""
               // }
              // var payloadString = String("")
               // if let data = data {
               //     if let payload = String(data: data, encoding: .utf8) {
                var roomString = String("")
                 roomString = "loc220" //Default room
                var payloadString = String("")
                var payloadTmp = String("")
                 if let data = data {
                     if let payload = String(data: data, encoding: .utf8) {
                         if (payload.count == 7)
                         {
                             payloadTmp = payload
                             roomString = "loc"+payloadTmp.substring(from:4)
                             payloadTmp = payloadTmp.substring(to:4)
                         }
                        else
                        {
                           payloadTmp = payload
                        }
                        if payloadTmp == "1111"
                        {
                                                   payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                   //payloadString = "EchoCare team welcomes you to Hackathon 2020 GBT Techonology Event! \n "
                                               }
                                               else if payloadTmp == "2222"{
                                                   payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                   //payloadString = "Thanks for event check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                               }
                                                else if payloadTmp == "3333"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "GBT Hackathon 2020 winners announcement to be held tomorrow at 4:00 PM MST in cafeteria. \n "
                                                }
                                                else if payloadTmp == "4444"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "EMERGENCY EVACUATION ALERT: Please follow EXIT sign to reach nearest exit. \n "
                                                }
                                                else if payloadTmp == "5555"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "For your information - Dell Boomi event booth location has been changed from 238 to 202 i.e. SW corner of the venue. \n "
                                                }
                                                else if payloadTmp == "6666"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "For your information - NetSuite technology demo is going to start in next 10 minutes at booth 220 i.e. SE corner of the venue. \n"
                                                }
                                                else if payloadTmp == "7777"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "Thank you for joining the GBT Hackathon 2020 event & hope you had great experience! \n"
                                                }
                                                else if payloadTmp == "8888"{
                                                    payloadString = "" //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                                    //payloadString = "Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                }
                                                else if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                {//Channel 2 only for Welcome messages
                                                    var userNameString = String("")
                                                    userNameString = ""
                                                                
                                                   if (UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "1965") //Srini's iPhone
                                                   {
                                                       userNameString = "Dear Srini, " //mapped to Srini Kolla
                                                   }
                                                   else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "B98D") //Srini's iPhone11 Max Pro emulator
                                                   {
                                                       userNameString = "Booth 220, " //mapped to Booth 220
                                                   }
                                                   else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "432B") //Vijay Yedira's iPhone 11
                                                    {
                                                        userNameString = "Dear Vijay Yedira, " //mapped to Vijay Yedira
                                                    }
                                                    else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "58A0") //Pradeep's iPhone 11
                                                    {
                                                        userNameString = "Dear Pradeep, " //mapped to Pradeep Chintam
                                                    }
                                                    else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "61E0") //Britto's iPhone 11
                                                    {
                                                        userNameString = "Dear Britto, " //mapped to Britto
                                                    }
                                                    
                                                    payloadString = userNameString+"Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                }
                                                else if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                {
                                                    payloadString = ""//Do nothing from same device
                                                }

                    
                        else
                        {
                            if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                            {
                                payloadString = "" //Do nothing from same device
                            }
                            else if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                            {
                                var userNameString = String("")
                                 userNameString = ""
                                             
                                if (UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "1965") //Srini's iPhone
                                {
                                    userNameString = "Dear Srini, " //mapped to Srini Kolla
                                }
                                else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "B98D") //Srini's iPhone11 Max Pro emulator
                                {
                                    userNameString = "Booth 220, " //mapped to Booth 220
                                }
                                else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "432B") //Vijay Yedira's iPhone11
                                {
                                    userNameString = "Dear Vijay Yedira, " //mapped to Vijay Yedira
                                }
                                else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "58A0") //Pradeep's iPhone11
                                {
                                    userNameString = "Dear Pradeep, " //mapped to Pradeep
                                }
                                else if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "61E0") //Britto's iPhone11
                                {
                                    userNameString = "Dear Britto, " //mapped to Britto
                                }
                                 
                                 payloadString = userNameString+"Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                            }
                            else
                            {
                                payloadString = ""
                               // payloadString = payload
                               // payloadString = "UDID: " + payload
                            }
                            
                            
                                                   /*
                                                   print(String(format: "Calling WebService1.....Start \n"))
                                                  
                                                    let urlString = "http://localhost:8080/updateUserLocation?userid=100&locationid=loc206"
                                         //
                                                   print(String(format: "WebService1 call completed.....End \n"))
                                                    */
                        }
                        /*
                        if payload.substring(to:1) != "$"
                        {
                            self.receivedText.text = payloadString + "\n" + self.receivedText.text
                        }
                        */
                        if (payloadString != "")
                        {
                            //Receive welcome msg for each check-in
                            if(checkinFlag == true)
                            {
                                print("checkinFlag1 is true")
                                checkinFlag = false
                                print("checkinFlag1 set to false")
                                
                                self.receivedText.text = payloadString + "\n" + self.receivedText.text
                                //Channel 2 for only Welcome messages (not for actual or UUID msg)
                                print(String(format: "Received1: %@", payloadString))
                               
                            }
                            
                        }
                        //Channel 2 is only for receiving Welcome messages (not for sending)
                        /*
                        if(checkinFlag == true)
                        {
                            print("checkinFlag1 is true")
                            checkinFlag = false
                            print("checkinFlag1 set to false")
                            recUUID = "$"+payload
                            print(String(format: "recUUID1 set to: %@", recUUID ?? ""))
                            print("Calling sendWelcomeMsg1")
                            self.sendWelcomeMsg()
                            //self.sendThankYouMsg()
                        }
                        */
                    } else {
                        print("Failed to decode UDID payload!")
                    }
                } else {
                    print("Decode UDID failed!")
                }
                return;
            }
        }
        /**/
        if let sdk2 = appDelegate.sdk2 {

            print(sdk2.version);

            sdk2.sendingBlock = {
                (data : Data?, channel: UInt?) -> () in
                print("SENDING UUID \n")
                return;
            }
            
            sdk2.sentBlock = {
                (data : Data?, channel: UInt?) -> () in
                print("SENT UUID \n")
                return;
            }

            sdk2.receivingBlock = {
                (channel: UInt?) -> () in
                self.configureSendButton(enabled: false, title: "RECEIVING UDID", colour: self.chirpGrey)
                 // self.receivedText.text = "...."
                  self.receivedText.text =  self.receivedText.text + ""
                    return;
            }

            sdk2.receivedBlock = {
                    (data : Data?, channel: UInt?) -> () in
                     self.configureSendButton(enabled: true, title: "SEND", colour: self.chirpBlue)
                   // if self.inputText.text == "...." {
                    //    self.inputText.text = ""
                   // }
                   var roomString = String("")
                    roomString = "loc220" //Default room
                   var payloadString = String("")
                   var payloadTmp = String("")
                    if let data = data {
                        if let payload = String(data: data, encoding: .utf8) {
                            if (payload.count == 7)
                            {
                                payloadTmp = payload
                                roomString = "loc"+payloadTmp.substring(from:4)
                                payloadTmp = payloadTmp.substring(to:4)
                            }
                            else
                            {
                               payloadTmp = payload
                            }
                            if payloadTmp == "1111"
                            {
                                                    payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                    //payloadString = "EchoCare team welcomes you to Hackathon 2020 GBT Techonology Event! \n "
                                                   }
                                                   else if payloadTmp == "2222"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                       //payloadString = "Thanks for event check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                   }
                                                    else if payloadTmp == "3333"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "GBT Hackathon 2020 winners announcement to be held tomorrow at 4:00 PM MST in cafeteria. \n "
                                                    }
                                                    else if payloadTmp == "4444"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "EMERGENCY EVACUATION ALERT: Please follow EXIT sign to reach nearest exit. \n "
                                                    }
                                                    else if payloadTmp == "5555"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "For your information - Dell Boomi event booth location has been changed from 238 to 202 i.e. SW corner of the venue. \n "
                                                    }
                                                    else if payloadTmp == "6666"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "For your information - NetSuite technology demo is going to start in next 10 minutes at booth 220 i.e. SE corner of the venue. \n"
                                                    }
                                                    else if payloadTmp == "7777"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "Thank you for joining the GBT Hackathon 2020 event & hope you had great experience! \n"
                                                    }
                                                    else if payloadTmp == "8888"{
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                                        //payloadString = "Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                    }
                                                    else if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                    {
                                                        payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages) //UIDevice.current.identifierForVendor!.uuidString.substring(from:31)+":"+"Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
                                                    }
                                                    else if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                                    {
                                                        payloadString = ""//Do nothing from same device
                                                    }

                        
                            else
                            {
                                if payloadTmp == ("$"+UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                {
                                    payloadString = "" //Channel 3 is only for receiving  UUID messages (not for actual or Welcome messages)
                                }
                                else if payloadTmp == (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                {
                                    payloadString = "" //Do nothing from same device
                                }
                                else
                                {
                                    if (payloadTmp.count == 4 && payloadTmp.substring(to:1) != "$")
                                    {
                                        var usrString = String("")
                                        var urlTempString = String("")
                                        
                                        usrString = "100" //Default user value
                                       // roomString = "loc220" //Default room value
                                        urlTempString = "http://localhost:8080/updateUserLocation?userid="+usrString+"&locationid="+roomString //Default url value
                                        
                                        print(urlTempString)
                                        
                                        var userNameString = String("")
                                         userNameString = ""
                                                     
                                        if (payloadTmp == "1965") //Srini's iPhone
                                        {
                                            userNameString = "Srini" //mapped to Srini Kolla
                                        }
                                        else if(payloadTmp == "B98D") //Srini's iPhone11 Max Pro emulator
                                        {
                                            userNameString = "Booth 220" //mapped to Booth 220
                                        }
                                        else if(payloadTmp == "432B") //Vijay Yedira's iPhone 11
                                         {
                                             userNameString = "Vijay Yedira" //mapped to Vijay Yedira
                                         }
                                        else if(payloadTmp == "58A0") //Pradeep's iPhone 11
                                        {
                                            userNameString = "Pradeep" //mapped to Pradeep
                                        }
                                        else if(payloadTmp == "61E0") //Britto's iPhone 11
                                        {
                                            userNameString = "Britto" //mapped to Britto
                                        }
                                        
                                        if payloadTmp != (UIDevice.current.identifierForVendor!.uuidString.substring(from:32))
                                        {
                                            if(UIDevice.current.identifierForVendor!.uuidString.substring(from:32) == "B98D") //Srini's iPhone11 Max Pro emulator as terminal
                                            {
                                                payloadString = userNameString+" has been checked-in to location id: " + roomString.substring(from: 3)//payload
                                                    
                                                    print(payloadString)
                                                    print(String(format: "UDID2 Received: %@", payloadTmp))
                                            }
                                        }
                                        
                                        
                                        
                                        //Send welcome msg when UUID received
                                        recUUID = "$"+payloadTmp
                                        print(String(format: "recUUID2 set to: %@", recUUID ?? ""))
                                        print("Calling sendWelcomeMsg2")
                                        if (payloadTmp == "1965") //Srini's iPhone
                                        {
                                            usrString = "100" //mapped to Srini Kolla
                                        }
                                        else if(payloadTmp == "B98D") //Srini's iPhone11 Max Pro emulator
                                        {
                                            usrString = "47" //mapped to Booth 220
                                        }
                                        else if(payloadTmp == "432B") //Vijay Yedira's iPhone11
                                        {
                                            usrString = "82" //mapped to Vijay Yedira
                                        }
                                        else if(payloadTmp == "58A0") //Pradeep's iPhone11
                                        {
                                            usrString = "96" //mapped to Pradeep
                                        }
                                        else if(payloadTmp == "61E0") //Britto's iPhone11
                                        {
                                            usrString = "25" //mapped to Britto
                                        }
                                        
                                        self.sendWelcomeMsg()
                                        
                                       /* if (self.inputText.text.count == 3)//Not working
                                        {
                                            roomString = "loc"+self.inputText.text
                                        }
                                        */
                                        /*if(checkinFlag == true)
                                        {
                                            print("checkinFlag2 is true")
                                            checkinFlag = false
                                            print("checkinFlag2 set to false")
                                            recUUID = "$"+payload
                                            print(String(format: "recUUID2 set to: %@", recUUID ?? ""))
                                            print("Calling sendWelcomeMsg2")
                                            self.sendWelcomeMsg()
                                            //self.sendThankYouMsg()
                                        }*/
                                                  
                                                  print(String(format: "Calling WebService2.....Start \n"))
                                                 
                                          //         let urlString = "http://localhost:8080/updateUserLocation?userid=100&locationid=loc206"
                                       urlTempString = "http://localhost:8080/updateUserLocation?userid="+usrString+"&locationid="+roomString
                                    
                                       print(urlTempString)
                                        
                                       let urlString = URL(string: urlTempString)  // Making the URL
                                        
                                       if let url = urlString {
                                          let task = URLSession.shared.dataTask(with: url) {
                                             (data, response, error) in // Creating the URL Session.
                                            if error != nil {
                                                // Checking if error exist.
                                                print(error?.localizedDescription ?? "ERROR")
                                             } else {
                                                if let usableData = data {
                                                   // Checking if data exist.
                                                   print(usableData)
                                                   // printing Data.
                                                }
                                             }
                                          }
                                        task.resume()
                                       }
                                       
                                        //
                                                  print(String(format: "WebService2 call completed.....End \n"))
                                    }
                                    else
                                    {
                                        payloadString = ""
                                    }
                                    //payloadString = "UDID2: " + payload
                                }
                                
                            }
                            /*
                            if payload.substring(to:1) != "$"
                            {
                                self.receivedText.text = payloadString + "\n" + self.receivedText.text
                            }
                            */
                            
                            if (payloadString != "")
                            {
                                self.receivedText.text = payloadString + "\n" + self.receivedText.text
                                //Send welcome msg when UUID received
                                /*if(checkinFlag == true)
                                {
                                    print("checkinFlag2 is true")
                                    checkinFlag = false
                                    print("checkinFlag2 set to false")
                                    recUUID = "$"+payload
                                    print(String(format: "recUUID2 set to: %@", recUUID ?? ""))
                                    print("Calling sendWelcomeMsg2")
                                    self.sendWelcomeMsg()
                                    //self.sendThankYouMsg()
                                }*/
                                
                            }
                            
                        } else {
                            print("Failed to decode UDID payload!")
                        }
                    } else {
                        print("Decode UDID failed!")
                    }
                    return;
                }
            }
       /* */
    }
    

    /*
     * Ensure buttons are not left disabled when
     * returning from the background.
     */
    @objc func appMovedToBackground() {
        self.configureSendButton(enabled: true, title: "SEND", colour: self.chirpBlue)
        //self.receivedText.text = "Received message: "
         self.receivedText.text =  "" + self.receivedText.text
    }

    @objc func fire()
    {
        print("Sending UUID from Timer!!!")
        self.sendInput1()
    }
    
    /*
     * Configure the send buttons properties
     */
    func configureSendButton(enabled: Bool, title: String, colour: UIColor) {
        self.sendButton.isEnabled = enabled
        self.sendButton.setTitle(title, for: .normal)
        self.sendButton.backgroundColor = colour
    }
    
    /*
     * Configure the clear buttons properties
     */
    func configureClearButton(enabled: Bool, title: String, colour: UIColor) {
        self.clearButton.isEnabled = enabled
        self.clearButton.setTitle(title, for: .normal)
        self.clearButton.backgroundColor = colour
    }
    
    /*
     * Configure the ping UUID buttons properties
     */
    func configurePingUUIDButton(enabled: Bool, title: String, colour: UIColor) {
        self.pingUUIDButton.isEnabled = enabled
        self.pingUUIDButton.setTitle(title, for: .normal)
        self.pingUUIDButton.backgroundColor = colour
    }
    
    
    /*
     * Convert inputText to NSData and send to the speakers.
     * Check volume is turned up enough before doing so.
     */
    func sendInput() {
        if AVAudioSession.sharedInstance().outputVolume < 0.1 {
            let errmsg = "Please turn the volume up to send messages"
            let alert = UIAlertController(title: "Alert", message: errmsg, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            var payloadString = String("")
            if let sdk = appDelegate.sdk {
                if self.inputText.text == "EchoCare team welcomes you to Hackathon 2020 GBT Techonology Event! \n "{
                    payloadString = "1111"
                }
                else if self.inputText.text == "Thanks for event check-in, here is your coupon code : 98721-1237-128937123991237 \n "{
                    payloadString = "2222"
                }
                else if self.inputText.text == "GBT Hackathon 2020 winners announcement to be held tomorrow at 4:00 PM MST in cafeteria. \n "{
                    payloadString = "3333"
                }
                else if self.inputText.text == "EMERGENCY EVACUATION ALERT: Please follow EXIT sign to reach nearest exit. \n "{
                    payloadString = "4444"
                }
                else if self.inputText.text == "For your information - Dell Boomi event booth location has been changed from 238 to 202 i.e. SW corner of the venue. \n "{
                    payloadString = "5555"
                }
                else if self.inputText.text == "For your information - NetSuite technology demo is going to start in next 10 minutes at booth 220 i.e. SE corner of the venue. \n"{
                    payloadString = "6666"
                }
                else if self.inputText.text == "Thank you for joining the GBT Hackathon 2020 event & hope you had great experience! \n"{
                    payloadString = "7777"
                }
                else if self.inputText.text == "Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "{
                    payloadString = "8888"
                }
                else
                {
                    payloadString = self.inputText.text
                }
                let data = payloadString.data(using: .utf8)
                if let data = data {
                    if let error = sdk.send(data) {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
    
    /*
     * Convert inputText to NSData and send to the speakers.
     * Check volume is turned up enough before doing so.
     */
    func sendInput1() {
        
        var roomString = String("")
        roomString = "220" //Default room value
        if (self.inputText.text.count == 3)//pass room number
        {
            roomString = self.inputText.text
        }
        let uuid = UIDevice.current.identifierForVendor!.uuidString.substring(from:32)+roomString
        
        print("UUID: \(uuid)")
        
            if AVAudioSession.sharedInstance().outputVolume < 0.1 {
                let errmsg = "Please turn the volume up to send messages"
                let alert = UIAlertController(title: "Alert", message: errmsg, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else {
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                if let sdk1 = appDelegate.sdk1 {
 
                    let data = uuid.data(using: .utf8)
                    if let data = data {
                        if let error = sdk1.send(data) {
                            print(error.localizedDescription)
                        }
                    }
                }
            }
    }
    
    /*
        * Convert inputText to NSData and send to the speakers.
        * Check volume is turned up enough before doing so.
        */
    /**/
       func sendInput2() { //NOT BEING USED
           
           let uuid = UIDevice.current.identifierForVendor!.uuidString.substring(from:32)
           print("UUID: \(uuid)")
           
               if AVAudioSession.sharedInstance().outputVolume < 0.1 {
                   let errmsg = "Please turn the volume up to send messages"
                   let alert = UIAlertController(title: "Alert", message: errmsg, preferredStyle: UIAlertController.Style.alert)
                   alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                   self.present(alert, animated: true, completion: nil)
               } else {
                   let appDelegate = UIApplication.shared.delegate as! AppDelegate
                   if let sdk2 = appDelegate.sdk2 {
    
                       let data = uuid.data(using: .utf8)
                       if let data = data {
                           if let error = sdk2.send(data) {
                               print(error.localizedDescription)
                           }
                       }
                   }
               }
       }
   /* */
    /*
        * Convert inputText to NSData and send to the speakers.
        * Check volume is turned up enough before doing so.
        */
       func sendWelcomeMsg() {
           
   //        let welcome = "8888" //Welcome Message
        let recUUID1 = (recUUID ?? "")
        
           print("called sendWelcomeMsg")
               if AVAudioSession.sharedInstance().outputVolume < 0.1 {
                   let errmsg = "Please turn the volume up to send messages"
                   let alert = UIAlertController(title: "Alert", message: errmsg, preferredStyle: UIAlertController.Style.alert)
                   alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                   self.present(alert, animated: true, completion: nil)
               } else {
                   let appDelegate = UIApplication.shared.delegate as! AppDelegate
                   if let sdk2 = appDelegate.sdk2 {
    
                    let data = recUUID1.data(using: .utf8)
                       if let data = data {
                           if let error = sdk2.send(data) {
                               print(error.localizedDescription)
                           }
                       }
                   }
               }
        print("sentWelcomeMsg")
       }
    
    /*
        * Convert inputText to NSData and send to the speakers.
        * Check volume is turned up enough before doing so.
        */
    /**/
       func sendThankYouMsg() {
           
           let thankyou = "2222" //Welcome Message
           
               if AVAudioSession.sharedInstance().outputVolume < 0.1 {
                   let errmsg = "Please turn the volume up to send messages"
                   let alert = UIAlertController(title: "Alert", message: errmsg, preferredStyle: UIAlertController.Style.alert)
                   alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                   self.present(alert, animated: true, completion: nil)
               } else {
                   let appDelegate = UIApplication.shared.delegate as! AppDelegate
                   if let sdk2 = appDelegate.sdk2 {
    
                       let data = thankyou.data(using: .utf8)
                       if let data = data {
                           if let error = sdk2.send(data) {
                               print(error.localizedDescription)
                           }
                       }
                   }
               }
       }
    /**/
    /*
     * Check the inputText on click.
     */
    func textViewDidBeginEditing(_ textView: UITextView) {
        if self.inputText.text == "Enter message..." {
            self.inputText.text = ""
        }
        
    }
    
    
    /*
     * Check the inputText on text view change.
     */
    func textViewDidChange(_ textView: UITextView) {
       /* if self.inputText.text == "Enter message..." {
            self.inputText.text = ""
        }
        else
 */     if self.inputText.text == "1111"{
            self.inputText.text = "EchoCare team welcomes you to Hackathon 2020 GBT Techonology Event! \n "
        }
        else if self.inputText.text == "2222"{
            self.inputText.text = "Thanks for event check-in, here is your coupon code : 98721-1237-128937123991237 \n "
        }else if self.inputText.text == "3333"{
            self.inputText.text = "GBT Hackathon 2020 winners announcement to be held tomorrow at 4:00 PM MST in cafeteria. \n "
        }else if self.inputText.text == "4444"{
            self.inputText.text = "EMERGENCY EVACUATION ALERT: Please follow EXIT sign to reach nearest exit. \n "
        }else if self.inputText.text == "5555"{
            self.inputText.text = "For your information - Dell Boomi event booth location has been changed from 238 to 202 i.e. SW corner of the venue. \n "
        }else if self.inputText.text == "6666"{
            self.inputText.text = "For your information - NetSuite technology demo is going to start in next 10 minutes at booth 220 i.e. SE corner of the venue. \n"
        }else if self.inputText.text == "7777"{
            self.inputText.text = "Thank you for joining the GBT Hackathon 2020 event & hope you had great experience! \n"
        }else if self.inputText.text == "8888"{
            self.inputText.text = "Thanks for check-in, here is your coupon code : 98721-1237-128937123991237 \n "
        }else if self.inputText.text == "0000"{
            self.minimiseKeyboard()
            // self.sendInput()
             self.inputText.text = "Enter message..."
             self.receivedText.text = ""
        }else if self.inputText.text == "9999"{
            self.minimiseKeyboard()
            // self.sendInput()
             self.inputText.text = "Enter message..."
             //self.receivedText.text = ""
        }

    }

     @IBAction func send(_ sender: Any) {
           self.minimiseKeyboard()
           self.sendInput()
       }
    
    @IBAction func clear(_ sender: Any) {
        self.minimiseKeyboard()
       // self.sendInput()
        self.inputText.text = "Enter message..."
    }
    
    @IBAction func pingUUID(_ sender: Any) {
        checkinFlag = true
        print("checkinFlag = true")
        self.minimiseKeyboard()
        self.sendInput1()
    }

    /*
     * Check the length of the data does not exceed
     * the max payload length.
     * Catch any return keys in the inputText view
     * and close the keyboard.
     */
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        let data = self.inputText.text.data(using: .utf8)
    
        if let data = data {
            //let appDelegate = UIApplication.shared.delegate as! AppDelegate
            //if let sdk = appDelegate.sdk {
                //if data.count >= sdk.maxPayloadLength, text != "" {
                if data.count >= 500, text != "" {
                    return false
                }
           // }
        }
        return true
    }
    
    /*
     * Minimise keyboard.
     */
    func minimiseKeyboard() {
        self.inputText.resignFirstResponder()
        self.view.endEditing(true)
    }
    
    @objc func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        self.minimiseKeyboard()
    }

    @IBOutlet var pingUUIDButton: UIButton!
    @IBOutlet var clearButton: UIButton!
    @IBOutlet var sendButton: UIButton!
    @IBOutlet var inputText: UITextView!
    @IBOutlet var receivedText: UITextView!
}

